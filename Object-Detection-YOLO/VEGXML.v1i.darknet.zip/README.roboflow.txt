
VEGXML - v1 2021-03-25 10:32pm
==============================

This dataset was exported via roboflow.ai on March 25, 2021 at 5:04 PM GMT

It includes 824 images.
VEGXML are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip


